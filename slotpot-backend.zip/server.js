require('dotenv').config();
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const adminAutomation = require('./services/adminAutomation');
const contractService = require('./services/contractService');
const socketService = require('./services/socketService');
const userService = require('./services/userService');

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 5002;

// Configure CORS for both Express and Socket.io
const corsOptions = {
  origin: [
    "http://localhost:3000", 
    "http://localhost:3001",
    process.env.FRONTEND_URL,
    process.env.REACT_APP_BACKEND_URL,
    // Allow Vercel deployments
    /^https:\/\/.*\.vercel\.app$/,
    // Allow connections from your local network
    /^http:\/\/192\.168\.\d+\.\d+:\d+$/,
    /^http:\/\/10\.\d+\.\d+\.\d+:\d+$/,
    /^http:\/\/172\.(1[6-9]|2\d|3[01])\.\d+\.\d+:\d+$/
  ].filter(Boolean),
  methods: ["GET", "POST"],
  credentials: true
};

// Initialize the socket service with the HTTP server
socketService.initialize(server);
console.log('🔌 Socket service initialized with HTTP server');

// Middleware
app.use(cors(corsOptions));
app.use(express.json());

// In-memory storage for chat (replace with database in production)
let chatMessages = [];
let connectedUsers = new Map();

// Serve static files from React build in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../build')));
}

// Simple rate limiting middleware for specific endpoints
const rateLimiters = new Map();

function rateLimitMiddleware(endpoint, maxRequests = 50, windowMs = 60000) {
  return (req, res, next) => {
    const key = `${req.ip}-${endpoint}`;
    const now = Date.now();
    
    if (!rateLimiters.has(key)) {
      rateLimiters.set(key, { count: 1, resetTime: now + windowMs });
      return next();
    }
    
    const limiter = rateLimiters.get(key);
    
    if (now > limiter.resetTime) {
      // Reset the limiter
      limiter.count = 1;
      limiter.resetTime = now + windowMs;
      return next();
    }
    
    if (limiter.count >= maxRequests) {
      console.log(`🚦 Rate limited ${endpoint} for IP ${req.ip} (${limiter.count}/${maxRequests} requests in ${windowMs/1000}s window)`);
      return res.status(429).json({ 
        error: 'Too many requests', 
        retryAfter: Math.ceil((limiter.resetTime - now) / 1000),
        maxRequests: maxRequests,
        windowSeconds: windowMs / 1000,
        message: `Rate limit exceeded for ${endpoint}. Try again in ${Math.ceil((limiter.resetTime - now) / 1000)} seconds.`
      });
    }
    
    limiter.count++;
    next();
  };
}

// ======================
// CONTRACT API ROUTES
// ======================

// CONTRACT API ROUTES REMOVED - ALL DATA NOW BROADCAST VIA SOCKET

// ======================
// ADMIN API ROUTES
// ======================

app.get('/api/admin/status', rateLimitMiddleware('admin-status', 10, 30000), (req, res) => {
  // Log the request for debugging
  console.log(`📊 Admin status requested from ${req.ip} at ${new Date().toISOString()}`);
  
  const status = adminAutomation.getStatus();
  res.json(status);
});

app.post('/api/admin/settings', (req, res) => {
  try {
    const { roundDuration, minBetsToEnd } = req.body;
    
    if (roundDuration) {
      adminAutomation.setRoundDuration(roundDuration);
    }
    
    if (minBetsToEnd) {
      adminAutomation.setMinBetsToEnd(minBetsToEnd);
    }
    
    res.json({ success: true, message: 'Settings updated' });
  } catch (error) {
    console.error('Error updating settings:', error);
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

// Emergency admin controls (require admin key)
app.post('/api/admin/force-start', (req, res) => {
  const { adminKey } = req.body;
  
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  try {
    adminAutomation.forceStartRound();
    res.json({ success: true, message: 'Round force started' });
  } catch (error) {
    console.error('Error force starting round:', error);
    res.status(500).json({ error: 'Failed to force start round' });
  }
});

app.post('/api/admin/force-end', (req, res) => {
  const { adminKey } = req.body;
  
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  try {
    adminAutomation.forceEndRound();
    res.json({ success: true, message: 'Round force ended' });
  } catch (error) {
    console.error('Error force ending round:', error);
    res.status(500).json({ error: 'Failed to force end round' });
  }
});

// Test winner broadcast endpoint
app.post('/api/admin/test-winner', (req, res) => {
  const { adminKey } = req.body;
  
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  try {
    const result = adminAutomation.testWinnerBroadcast();
    res.json({ 
      success: true, 
      message: 'Test winner broadcast sent',
      broadcasted: result
    });
  } catch (error) {
    console.error('Error sending test winner broadcast:', error);
    res.status(500).json({ error: 'Failed to send test winner broadcast' });
  }
});

// ======================
// USER API ROUTES
// ======================

// Register or update user information
app.post('/api/user/register', (req, res) => {
  try {
    const { address, username, firstName, lastName, telegramId } = req.body;
    
    if (!address) {
      return res.status(400).json({ error: 'Wallet address is required' });
    }
    
    const userData = {
      username: username,
      firstName: firstName,
      lastName: lastName,
      telegramId: telegramId
    };
    
    const success = userService.registerUser(address, userData);
    
    if (success) {
      const userInfo = userService.getUserInfo(address);
      res.json({ 
        success: true, 
        message: 'User registered successfully',
        user: userInfo
      });
    } else {
      res.status(500).json({ error: 'Failed to register user' });
    }
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ error: 'Failed to register user' });
  }
});

// Get user information by address
app.get('/api/user/:address', (req, res) => {
  try {
    const { address } = req.params;
    const userInfo = userService.getUserInfo(address);
    
    if (userInfo) {
      res.json(userInfo);
    } else {
      res.status(404).json({ error: 'User not found' });
    }
  } catch (error) {
    console.error('Error getting user info:', error);
    res.status(500).json({ error: 'Failed to get user info' });
  }
});

// Update username for an address
app.post('/api/user/update-username', (req, res) => {
  try {
    const { address, username } = req.body;
    
    if (!address || !username) {
      return res.status(400).json({ error: 'Address and username are required' });
    }
    
    const success = userService.registerUser(address, { username });
    
    if (success) {
      const userInfo = userService.getUserInfo(address);
      res.json({ 
        success: true, 
        message: 'Username updated successfully',
        user: userInfo
      });
    } else {
      res.status(500).json({ error: 'Failed to update username' });
    }
  } catch (error) {
    console.error('Error updating username:', error);
    res.status(500).json({ error: 'Failed to update username' });
  }
});

// Get all registered users (admin only)
app.get('/api/admin/users', (req, res) => {
  try {
    const users = userService.getAllUsers();
    const stats = userService.getStats();
    
    res.json({
      users: users,
      stats: stats
    });
  } catch (error) {
    console.error('Error getting users:', error);
    res.status(500).json({ error: 'Failed to get users' });
  }
});

// ======================
// CHAT API ROUTES
// ======================

// Get chat history
app.get('/api/chat/messages', (req, res) => {
  res.json({
    messages: chatMessages.slice(-50), // Last 50 messages
    totalUsers: connectedUsers.size
  });
});

// Get game state (combined with contract data)
app.get('/api/game/state', async (req, res) => {
  try {
    const contractState = await contractService.getContractState();
    const adminStatus = adminAutomation.getStatus();
    
    res.json({
      ...contractState,
      // Add timer information directly to game state
      currentRound: adminStatus.currentRound,
      roundDuration: adminStatus.roundDuration,
      timer: {
        isActive: adminStatus.currentRound.isActive,
        timeRemaining: adminStatus.currentRound.timeRemaining,
        timeElapsed: adminStatus.currentRound.timeElapsed,
        roundNumber: adminStatus.currentRound.roundNumber
      },
      players: [] // This could be populated from connected users or contract data
    });
  } catch (error) {
    console.error('Error fetching game state:', error);
    res.status(500).json({ error: 'Failed to fetch game state' });
  }
});

// Notify about bet placement
app.post('/api/game/bet-notification', (req, res) => {
  try {
    const { amount, address, username } = req.body;
    
    // Register/update user if we have username info
    if (address && username) {
      userService.registerUser(address, { username });
    }
    
    // Calculate net amount after 0.5 TON fee
    const netAmount = Math.max(0, parseFloat(amount) - 0.5);
    
    // Get the actual username from user service (or fallback)
    const actualUsername = address ? userService.getUsername(address) : 'Unknown Player';
    
    // Create bet notification message with net amount
    const betMessage = {
      id: uuidv4(),
      username: 'system',
      message: `🎰 ${actualUsername} placed a bet of ${amount} TON (${netAmount.toFixed(3)} TON to jackpot)!`,
      timestamp: new Date(),
      type: 'bet'
    };

    // Add to chat history
    chatMessages.push(betMessage);
    
    // Keep only last 100 messages
    if (chatMessages.length > 100) {
      chatMessages = chatMessages.slice(-100);
    }

    // Broadcast to all connected users
    socketService.broadcastChatMessage(betMessage);
    
    console.log(`🎰 Bet notification: ${actualUsername} - ${amount} TON (${netAmount.toFixed(3)} TON net)`);
    
    res.json({ success: true, message: 'Bet notification sent', username: actualUsername });
  } catch (error) {
    console.error('Error sending bet notification:', error);
    res.status(500).json({ error: 'Failed to send bet notification' });
  }
});

// Health check endpoint with rate limiting status
app.get('/api/health', (req, res) => {
  const adminStatus = adminAutomation.getStatus();
  const contractCacheStatus = contractService.getCacheStatus();
  const pollingStatus = getPollingStatus();
  
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    admin: {
      isInitialized: adminStatus.isInitialized,
      isHealthy: adminAutomation.isHealthy(),
      totalRoundsStarted: adminStatus.stats.roundsStarted,
      totalRoundsEnded: adminStatus.stats.roundsEnded,
      totalErrors: adminStatus.stats.errors
    },
    contract: {
      cacheStatus: contractCacheStatus,
      endpoint: process.env.TON_ENDPOINT,
      hasApiKey: !!process.env.TON_API_KEY
    },
    polling: pollingStatus,
    settings: {
      requestDelay: adminStatus.requestDelay,
      cacheExpiry: contractCacheStatus.cacheExpiry
    }
  });
});

// Get polling status endpoint
app.get('/api/contract/polling-status', (req, res) => {
  const status = getPollingStatus();
  res.json({
    success: true,
    ...status,
    dataFreshness: status.hasData ? 
      (status.dataAge < 10000 ? 'fresh' : 
       status.dataAge < 30000 ? 'stale' : 'old') : 'none'
  });
});

// Manual polling trigger (admin only)
app.post('/api/contract/force-poll', (req, res) => {
  const { adminKey } = req.body;
  
  if (adminKey !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  // Trigger immediate poll
  pollContractState()
    .then(() => {
      res.json({ 
        success: true, 
        message: 'Manual poll triggered',
        status: getPollingStatus()
      });
    })
    .catch((error) => {
      res.status(500).json({ 
        success: false, 
        error: error.message,
        status: getPollingStatus()
      });
    });
});

// Rate limiting status endpoint
app.get('/api/admin/rate-limit-status', (req, res) => {
  try {
    const adminStatus = adminAutomation.getStatus();
    const contractStatus = contractService.getCacheStatus();
    
    res.json({
      success: true,
      data: {
        automation: {
          rateLimitErrors: adminStatus.stats.rateLimitErrors,
          totalErrors: adminStatus.stats.errors,
          lastError: adminStatus.stats.lastError,
          isHealthy: adminAutomation.isHealthy(),
          cache: adminStatus.cacheStatus
        },
        contractService: contractStatus,
        recommendations: {
          increaseInterval: adminStatus.stats.rateLimitErrors > 10,
          increaseDelay: adminStatus.stats.rateLimitErrors > 5,
          getApiKey: !process.env.TON_API_KEY && adminStatus.stats.rateLimitErrors > 0
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Clear caches endpoint
app.post('/api/admin/clear-cache', (req, res) => {
  try {
    adminAutomation.clearCache();
    contractService.clearCache();
    
    res.json({
      success: true,
      message: 'All caches cleared successfully'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// ======================
// SOCKET.IO CHAT FUNCTIONALITY
// ======================

socketService.setupSocketEventHandlers((socket) => {
  console.log(`🔌 User connected: ${socket.id}`);

  // Handle user joining
  socket.on('user:join', (userData) => {
    const user = {
      id: socket.id,
      username: userData.username || `User${Math.floor(Math.random() * 1000)}`,
      avatar: userData.avatar || '👤',
      joinedAt: new Date(),
      isOnline: true
    };
    
    connectedUsers.set(socket.id, user);
    
    // Notify others about new user
    socket.broadcast.emit('user:joined', {
      username: user.username,
      totalUsers: connectedUsers.size
    });

    // Send current chat history to new user
    socket.emit('chat:history', chatMessages.slice(-50));
    
    console.log(`👤 ${user.username} joined the chat`);
  });

  // Handle chat messages
  socket.on('chat:message', (data) => {
    const user = connectedUsers.get(socket.id);
    if (!user) return;

    const message = {
      id: uuidv4(),
      username: user.username,
      message: data.message.trim(),
      timestamp: new Date(),
      type: 'user',
      avatar: user.avatar
    };

    // Add to chat history
    chatMessages.push(message);
    
    // Keep only last 100 messages
    if (chatMessages.length > 100) {
      chatMessages = chatMessages.slice(-100);
    }

    // Broadcast to all users
    socketService.broadcastChatMessage(message);

    console.log(`💬 ${user.username}: ${message.message}`);
  });

  // Handle betting notifications (when user places bet)
  socket.on('game:bet', (data) => {
    // Use username from bet data (from wallet registration) or fallback to chat user
    const chatUser = connectedUsers.get(socket.id);
    const username = data.username || chatUser?.username || 'Anonymous Player';
    
    console.log(`🎰 ${username} placed bet: ${data.amount} TON (from address: ${data.address?.slice(0, 8)}...)`);
    
    // Register user if we have address and username
    if (data.address && data.username) {
      userService.registerUser(data.address, { username: data.username });
    }
    
    // Broadcast bet notification using the actual username
    const betMessage = {
      id: uuidv4(),
      username: 'system',
      message: `🎰 ${username} placed a bet of ${data.amount} TON!`,
      timestamp: new Date(),
      type: 'bet'
    };

    chatMessages.push(betMessage);
    socketService.broadcastChatMessage(betMessage);
  });

  // Handle typing indicators
  socket.on('chat:typing', (isTyping) => {
    const user = connectedUsers.get(socket.id);
    if (!user) return;

    socket.broadcast.emit('user:typing', {
      username: user.username,
      isTyping
    });
  });

  // Handle user disconnect
  socket.on('disconnect', () => {
    const user = connectedUsers.get(socket.id);
    if (user) {
      connectedUsers.delete(socket.id);
      
      // Notify others about user leaving
      socket.broadcast.emit('user:left', {
        username: user.username,
        totalUsers: connectedUsers.size
      });

      console.log(`👋 ${user.username} left the chat`);
    }
  });
});

// ======================
// AUTOMATION EVENTS TO CHAT
// ======================

// Function to broadcast automation events to chat
function broadcastAutomationEvent(message, type = 'system') {
  const systemMessage = {
    id: uuidv4(),
    username: 'system',
    message: message,
    timestamp: new Date(),
    type: type
  };

  chatMessages.push(systemMessage);
  socketService.broadcastChatMessage(systemMessage);
}

// Listen for automation events (you can call these from adminAutomation service)
global.broadcastToChat = broadcastAutomationEvent;

// ======================
// BETTOR TRACKING - REMOVED (USING CONTRACT DATA ONLY)
// ======================

// All bettor data now comes from the contract via contractService.getAllBettors()
// All jackpot data now comes from the contract via contractService.getContractState()

// Calculate winner prize (95% of total jackpot)
function calculateWinnerPrize(totalJackpot) {
  return totalJackpot * 0.95; // Winner gets 95%, 5% is fee
}

// ======================
// BETTOR API ROUTES - REMOVED (ALL DATA NOW BROADCAST VIA SOCKET)
// ======================

// Make utility functions globally available for admin automation
global.calculateWinnerPrize = calculateWinnerPrize;
global.getCachedBettors = getCachedBettors;
global.getCachedContractState = getCachedContractState;

// ======================
// GLOBAL STATE MANAGER - POLLS CONTRACT EVERY 6 SECONDS
// ======================

let globalContractState = {
  contractState: null,
  bettors: [],
  lastUpdate: 0,
  isPolling: false,
  pollInterval: 6000, // 6 seconds
  errors: 0,
  consecutiveErrors: 0
};

// Background polling function
async function pollContractState() {
  if (globalContractState.isPolling) {
    console.log('⏳ Contract polling already in progress, skipping...');
    return;
  }

  globalContractState.isPolling = true;
  
  try {
    console.log('🔄 Polling contract state and bettors...');
    
    // Fetch contract state and bettors concurrently
    const [contractState, allBettors] = await Promise.all([
      contractService.getContractState(),
      contractService.getAllBettors()
    ]);
    
    // Update global state
    globalContractState.contractState = contractState;
    globalContractState.bettors = allBettors;
    globalContractState.lastUpdate = Date.now();
    globalContractState.consecutiveErrors = 0; // Reset error counter on success
    
    console.log(`✅ Contract state updated: ${allBettors.length} bettors, jackpot: ${contractState.totalJackpot} TON`);
    
    // Get admin status for timer information
    const adminStatus = adminAutomation.getStatus();
    
    // Create enhanced contract state with all necessary data
    const enhancedContractState = {
      // Contract data
      ...contractState,
      totalJackpot: parseFloat((contractState.totalJackpot || 0).toFixed(3)),
      betCount: allBettors.length,
      bettors: allBettors,
      
      // Timer data from admin automation
      currentRound: adminStatus.currentRound,
      roundDuration: adminStatus.roundDuration,
      timer: {
        isActive: adminStatus.currentRound.isActive,
        timeRemaining: adminStatus.currentRound.timeRemaining,
        timeElapsed: adminStatus.currentRound.timeElapsed,
        roundNumber: adminStatus.currentRound.roundNumber
      },
      
      // Metadata
      timestamp: globalContractState.lastUpdate,
      source: 'contract-polling',
      
      // Handle inactive state - zero everything if not active
      ...(contractState.isActive === false && {
        totalJackpot: 0,
        betCount: 0,
        bettors: [],
        userBettorData: null
      })
    };
    
    console.log(`📡 Broadcasting enhanced contract state: active=${enhancedContractState.isActive}, jackpot=${enhancedContractState.totalJackpot}, bettors=${enhancedContractState.betCount}`);
    
    // Broadcast complete state to all connected clients
    socketService.broadcastContractStateUpdate(enhancedContractState);
    
  } catch (error) {
    globalContractState.errors++;
    globalContractState.consecutiveErrors++;
    console.error('❌ Error polling contract state:', error);
    
    // If too many consecutive errors, increase polling interval
    if (globalContractState.consecutiveErrors >= 3) {
      globalContractState.pollInterval = Math.min(globalContractState.pollInterval * 1.5, 30000); // Max 30 seconds
      console.log(`⚠️ Too many errors, increasing poll interval to ${globalContractState.pollInterval}ms`);
    }
  } finally {
    globalContractState.isPolling = false;
  }
}

// Start background polling
function startContractPolling() {
  console.log(`🚀 Starting contract polling every ${globalContractState.pollInterval}ms`);
  
  // Initial poll
  pollContractState();
  
  // Set up interval
  const pollingInterval = setInterval(() => {
    pollContractState();
  }, globalContractState.pollInterval);
  
  // Graceful shutdown handling
  process.on('SIGTERM', () => {
    console.log('⏹️ Stopping contract polling...');
    clearInterval(pollingInterval);
  });
  
  process.on('SIGINT', () => {
    console.log('⏹️ Stopping contract polling...');
    clearInterval(pollingInterval);
  });
  
  return pollingInterval;
}

// Get current cached contract state
function getCachedContractState() {
  return globalContractState.contractState;
}

// Get current cached bettors
function getCachedBettors() {
  return globalContractState.bettors;
}

// Get polling status
function getPollingStatus() {
  return {
    lastUpdate: globalContractState.lastUpdate,
    isPolling: globalContractState.isPolling,
    pollInterval: globalContractState.pollInterval,
    errors: globalContractState.errors,
    consecutiveErrors: globalContractState.consecutiveErrors,
    dataAge: Date.now() - globalContractState.lastUpdate,
    hasData: !!globalContractState.contractState
  };
}

// ======================
// EXISTING MIDDLEWARE AND SETUP
// ======================

// Serve React app for any non-API routes in production
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../build', 'index.html'));
  });
}

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🌐 Server accessible at http://0.0.0.0:${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`💬 Socket.io: Ready for real-time chat`);
  console.log(`🎰 Contract API: Ready`);
  console.log(`🔧 Admin Service: Initializing...`);
  
  // Initialize services
  adminAutomation.initialize()
    .then(() => {
      console.log('✅ Admin automation initialized');
      
      // Inject socket service into admin automation for winner broadcasting
      adminAutomation.setSocketService(socketService);
      console.log('🔌 Socket service integrated with admin automation for winner broadcasting');
      
      // Start contract polling after admin automation is ready
      startContractPolling();
      console.log('📡 Contract state polling started');
    })
    .catch(error => {
      console.error('❌ Failed to initialize admin automation:', error);
      
      // Start polling anyway, even if admin automation fails
      startContractPolling();
      console.log('📡 Contract state polling started (admin automation failed)');
    });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('⏹️ SIGTERM received, shutting down gracefully...');
  broadcastAutomationEvent('🔴 Server is shutting down for maintenance', 'system');
  adminAutomation.stop();
  server.close(() => {
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('⏹️ SIGINT received, shutting down gracefully...');
  broadcastAutomationEvent('🔴 Server is shutting down', 'system');
  adminAutomation.stop();
  server.close(() => {
    process.exit(0);
  });
});

// Debug endpoint to show rate limiting status
app.get('/api/debug/rate-limits', (req, res) => {
  const now = Date.now();
  const limits = {};
  
  for (const [key, limiter] of rateLimiters.entries()) {
    const timeRemaining = Math.max(0, limiter.resetTime - now);
    limits[key] = {
      count: limiter.count,
      timeRemaining: Math.ceil(timeRemaining / 1000),
      resetTime: new Date(limiter.resetTime).toISOString()
    };
  }
  
  res.json({
    currentTime: new Date().toISOString(),
    rateLimiters: limits,
    totalLimiters: rateLimiters.size
  });
});

// Export for Vercel
module.exports = app; 