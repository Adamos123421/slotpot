class UserService {
  constructor() {
    // In-memory storage for usernames (in production, this should be a database)
    this.usernames = new Map(); // address -> {username, lastSeen, firstName, lastName}
    this.addressToUsernameCache = new Map(); // quick lookup
    
    console.log('👤 User service initialized');
  }

  // Register or update a user's information
  registerUser(address, userData) {
    if (!address) {
      console.error('❌ Cannot register user: no address provided');
      return false;
    }

    const normalizedAddress = address.toString();
    
    // Extract data with fallbacks
    const username = userData.username || 
                    userData.first_name || 
                    userData.firstName || 
                    `Player_${normalizedAddress.slice(-4)}`;
    
    const userInfo = {
      username: username,
      firstName: userData.first_name || userData.firstName || '',
      lastName: userData.last_name || userData.lastName || '',
      telegramId: userData.id || userData.telegramId || null,
      lastSeen: new Date(),
      registeredAt: this.usernames.has(normalizedAddress) ? 
                    this.usernames.get(normalizedAddress).registeredAt : 
                    new Date()
    };

    // Store the user info
    this.usernames.set(normalizedAddress, userInfo);
    this.addressToUsernameCache.set(normalizedAddress, username);

    console.log(`👤 User registered/updated: ${username} (${normalizedAddress.slice(0, 8)}...)`);
    return true;
  }

  // Get username for an address
  getUsername(address) {
    if (!address) return null;
    
    const normalizedAddress = address.toString();
    const userInfo = this.usernames.get(normalizedAddress);
    
    if (userInfo) {
      // Update last seen
      userInfo.lastSeen = new Date();
      return userInfo.username;
    }
    
    // Return fallback username if not found
    return `Player ${this.formatAddress(normalizedAddress)}`;
  }

  // Get full user info for an address
  getUserInfo(address) {
    if (!address) return null;
    
    const normalizedAddress = address.toString();
    const userInfo = this.usernames.get(normalizedAddress);
    
    if (userInfo) {
      // Update last seen
      userInfo.lastSeen = new Date();
      return { ...userInfo, address: normalizedAddress };
    }
    
    return {
      address: normalizedAddress,
      username: `Player ${this.formatAddress(normalizedAddress)}`,
      firstName: '',
      lastName: '',
      telegramId: null,
      lastSeen: new Date(),
      registeredAt: new Date()
    };
  }

  // Format address for display (same as contractService)
  formatAddress(address) {
    if (!address) return 'Unknown';
    const addressStr = address.toString();
    return `${addressStr.slice(0, 6)}...${addressStr.slice(-6)}`;
  }

  // Get all registered users
  getAllUsers() {
    const users = [];
    for (const [address, userInfo] of this.usernames.entries()) {
      users.push({
        address,
        ...userInfo
      });
    }
    return users.sort((a, b) => b.lastSeen - a.lastSeen); // Sort by most recent
  }

  // Check if user is registered
  isRegistered(address) {
    if (!address) return false;
    return this.usernames.has(address.toString());
  }

  // Update user's last seen timestamp
  updateLastSeen(address) {
    if (!address) return;
    
    const normalizedAddress = address.toString();
    const userInfo = this.usernames.get(normalizedAddress);
    
    if (userInfo) {
      userInfo.lastSeen = new Date();
    }
  }

  // Clean up old users (optional - for memory management)
  cleanupOldUsers(daysOld = 30) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - daysOld);
    
    let cleaned = 0;
    for (const [address, userInfo] of this.usernames.entries()) {
      if (userInfo.lastSeen < cutoff) {
        this.usernames.delete(address);
        this.addressToUsernameCache.delete(address);
        cleaned++;
      }
    }
    
    if (cleaned > 0) {
      console.log(`🧹 Cleaned up ${cleaned} old user entries`);
    }
    
    return cleaned;
  }

  // Get statistics
  getStats() {
    return {
      totalUsers: this.usernames.size,
      recentUsers: Array.from(this.usernames.values())
        .filter(user => (new Date() - user.lastSeen) < 24 * 60 * 60 * 1000).length, // Last 24h
      oldestUser: Math.min(...Array.from(this.usernames.values()).map(u => u.registeredAt)),
      newestUser: Math.max(...Array.from(this.usernames.values()).map(u => u.registeredAt))
    };
  }

  // Clear all users (for testing)
  clearAll() {
    const count = this.usernames.size;
    this.usernames.clear();
    this.addressToUsernameCache.clear();
    console.log(`🗑️ Cleared ${count} user entries`);
    return count;
  }
}

// Create singleton instance
const userService = new UserService();
module.exports = userService; 